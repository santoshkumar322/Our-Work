<?php
 include_once'database/db.php';
 if(isset($_POST['phone']))
	{
		$phone = $_POST['phone'];
		$sql = "SELECT count(*) as total from employee_details where phone='$phone'";
		$result=mysqli_query($conn, $sql);
		$data=mysqli_fetch_assoc($result);
		if($data['total'] > 0)
		{
		 echo 'duplicate';
		}
		else 
		{	
		 echo 'new';
		}
		mysqli_close($conn);
	}
?>