<!DOCTYPE html>
<html>
	<head>
		<title>Employee registration</title>
		<script>
			function validation()
			
			{
				if(document.getElementById("name").value=="")
				{
					alert("Enter Name");
					document.getElementById("name").focus();
					return false;
				}
				if(document.getElementById("email_id").value=="")
				{
					alert("Enter Email_id");
					document.getElementById("email_id").focus();
					return false;
				}
				else
				{
					var email_id=document.getElementById("email_id").value;
					var pat=/^([a-zA-Z0-9\_\.\-])+\@(([a-zA-Z0-9])+\.)+([a-zA-Z]{2,4})+$/;
					if(!pat.test(email_id))
					{
						alert("Please Enter Valid EMail_id");
						return false;
					}
				}
				if(document.getElementById("phone").value=="")
				{
					alert("Enter phone no");
				    document.getElementById("phone").focus();
					return false;
			}
			if(document.getElementById("department").value=="")
			{
				alert("Enter department");
				document.getElementById("department").focus();
				return false;
			}
			if(document.getElementById("remark").value=="")
			{
				alert("Enter remark");
			document.getElementById("remark").focus();
			return false;
			}
			}
</script>
</head>		

<?php
 include_once'database/db.php';
 if(isset($_POST['submit']))
{	

	 $name = $_POST['name'];
	 $email_id = $_POST['email_id'];
	 $phone = $_POST['phone'];
	 $department = $_POST['department'];
	 $remark = $_POST['remark'];
	 
	 $sql = "INSERT INTO employee_details(name,email_id,phone,department,remark)
	 VALUES('$name','$email_id','$phone','$department','$remark')";
	 if(mysqli_query($conn, $sql)) {
		echo "New record created successfully !";
	 } else {
		echo "Error: " . $sql . "" . mysqli_error($conn);
	 }
	 mysqli_close($conn);
}

?>
<style>
h1{
	color:darkblue;
}
</style>

<link rel="stylesheet" href="css/style.css">

<div class="container">
 <form method="post" action="erp.php" onSubmit="return validation()">
 <h1 align="center">Employee Registration Page:</h1>
    <div class="row">
      <div class="col-25">
        <label for="name">Name:</label>
      </div>
      <div class="col-75">
        <input type="text" id="name" name="name" placeholder="Your name" >
      </div>
    </div>
	 <div class="row">
      <div class="col-25">
        <label for="email_id">Email id:</label>
      </div>
      <div class="col-75">
        <input type="text" id="email_id" name="email_id" placeholder="Your email id" >
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="phone">Phone:</label>
      </div>
      <div class="col-75">
        <input type="text" id="phone" name="phone" placeholder="Your phone No" >
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="department">Department:</label>
      </div>
      <div class="col-75">
        <input type="text" id="department" name="department" placeholder="Your Department" >
      </div>
    </div>
    <div class="row">
      <div class="col-25">
      <label for="address">Remark:</label>
      </div>
      <div class="col-75">
      <input type="text" id="Remark" name="remark" placeholder="Remark here">
      </div>
    </div><br>
    <div class="row">
      <input type="submit" name="submit" value="Submit">
    </div>
  </form>
</div>
</html>