<!DOCTYPE html>
<html>
<head>
<title>Employee Registration form:</title>
<?php
 include_once'database/db.php';
 if(isset($_POST['submit']))
{	
	 
	 $name = $_POST['name'];
	 $email_id = $_POST['email_id'];
	 $phone = $_POST['phone'];
	 $department = $_POST['department'];
	 $remark = $_POST['remark'];
	 
	 $sql = "INSERT INTO employee_details(name,email_id,phone,department,remark)
	 VALUES('$name','$email_id','$phone','$department','$remark')";
	 if(mysqli_query($conn, $sql)) {
		echo "New record created successfully !";
	 } else {
		echo "Error: " . $sql . "" . mysqli_error($conn);
	 }
	 mysqli_close($conn);
}

?>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

<body>
<link rel="stylesheet" href="css/style.css">
  <div class="container">
    <h1 align="center">Employee Registration page:</h1>
	 <a  style="float:right;" href="index.php"><button type="button" class="btn btn-primary"><< Back</button></a>
    <form id="registrationForm" method="post" action="emp_reg.php" onsubmit="">
      <div class="form-group">
        <label for="name">Name:</label>
        <input type="text" class="form-control" id="name" name="name" required minlength="3" pattern="[A-Za-z]+" title="Enter a valid name minimum 3 characters, only alphabets"placeholder="Enter name">
      </div>
	  
      <div class="form-group">
        <label for="email_id">Email id:</label>
        <input type="email_id" class="form-control" id="email_id" name="email_id" placeholder="Enter email id" required>
        <small id="emailError" class="text-danger"></small>
      </div>
	  
      <div class="form-group">
        <label for="phone">Phone:</label>
        <input type="tel" class="form-control" id="phone" name="phone" required minlength="10" maxlength="10" pattern="[0-9]{10}" title="Enter 10 digit phone number" placeholder="Enter 10 digit mobile no">
        <small id="phoneError" class="text-danger"></small>
      </div>
	  
      <div class="form-group">
        <label for="department">Department:</label>
        <select class="form-control" id="department" name="department" required>
          <option value="">Select Department</option>
          <option value="IT Department">IT Department</option>
          <option value="SEO Department">SEO Department</option>
          <option value="Marketing Department">Marketing Department</option>
		  <option value="Other">Other</option>
        </select>
      </div>
	  
      <div class="form-group">
        <label for="remark">Remark:</label>
        <textarea class="form-control" id="remark" name="remark"></textarea>
      </div>
	  <input name="submit" value="submit" type="hidden">
      <button type="submit" class="btn btn-primary">Submit</button>
    </form>
  </div>

  <script>
    $(document).ready(function() {
      // Email validation and duplicate check using Ajax API
	  var isEmailValid= false;
	  var isPhoneValid= false;
      $('#email_id').on('input', function() {
        var email_id = $(this).val();
        $('#emailError').text('');

        if (email_id !== '') {
          $.ajax({
            url: 'check-email.php',
            method: 'POST',
            data: { email_id: email_id },
            success: function(response) {
              if (response === 'duplicate') {
                $('#emailError').text('Email id already exists.');
				 isEmailValid= false;
              }else {
				  isEmailValid= true;
			  }
            }
          });
        }
      });

      // Phone number validation and duplicate check using Ajax API
      $('#phone').on('input', function() {
        var phone = $(this).val();
        $('#phoneError').text('');

        if (phone.length === 10) {
          $.ajax({
            url: 'check-phone.php',
            method: 'POST',
            data: { phone: phone },
            success: function(response) {
              if (response === 'duplicate') {
                $('#phoneError').text('Phone number already exists.');
				  isPhoneValid= false;
              }else {
				  isPhoneValid= true;
			  }
            }
          });
        }
      });

      // Form submission
      $('#registrationForm').on('submit', function(e) {
		  if(isPhoneValid == false || isEmailValid == false){
			  e.preventDefault();
			  if(isEmailValid == false)
			   alert("Email id already exists.");
			  if(isPhoneValid == false)
			   alert("Phone number already exists.");
			  return false;
		  }
        
        // Perform further validation or submit the form to the backend
        // using Ajax or regular form submission.
        // You can use the values entered in the form fields like this:
        // var name = $('#name').val();
        // var email = $('#email').val();
        // var phone = $('#phone').val();
        // var department = $('#department').val();
        // var remark = $('#remark').val();
      });
    });
 </script>
</body>
</head>
</html>
