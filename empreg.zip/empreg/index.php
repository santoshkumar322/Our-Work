<!DOCTYPE html>
<html>
<head>
<title>Employee Listing</title>
<?php
 include_once'database/db.php';
 

?>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://unpkg.com/bootstrap-table@1.22.1/dist/bootstrap-table.min.css">
<script src="https://unpkg.com/bootstrap-table@1.22.1/dist/bootstrap-table.min.js"></script>
<body>
<link rel="stylesheet" href="css/style.css">
  <div class="container">
    <h1 align="center">Employee Listing</h1>
    <a href="emp_reg.php"><button type="button" class="btn btn-primary">Add Employee</button></a>
	<div class="row">
                    <div class="col-md-12">
                     
                        <table     id="table"
                                data-show-columns="true"
                                 data-height="460">
                        </table>
					</div>
				</div>
  </div>

 <script type="text/javascript">
    
     var $table = $('#table');
             $table.bootstrapTable({
                  url: 'list-user.php',
                  search: true,
                  pagination: true,
                  buttonsClass: 'primary',
                  showFooter: true,
                  minimumCountColumns: 2,
                  columns: [{
                      field: 'num',
                      title: '#',
                      sortable: true,
                  },{
                      field: 'name',
                      title: 'Name',
                      sortable: true,
                  },{
                      field: 'email_id',
                      title: 'Email',
                      sortable: true,
                      
                  },{
                      field: 'phone',
                      title: 'Phone',
                      sortable: true,
                  },{
                      field: 'department',
                      title: 'Department',
                      sortable: true,
                      
                  },{
                      field: 'remark',
                      title: 'Remark',
                      sortable: true,
					  
				  },{
                      field: 'Edit',
                      title: 'Edit',
                      sortable: true,
                      
				  },{
                      field: 'Delete',
                      title: 'Delete',
                      sortable: true,
                  } ],
 
               });

</script>
</body>
</head>
</html>
