<?php
 include_once'database/db.php';
 
  $sqltran = mysqli_query($conn, "SELECT * FROM employee_details ")or die(mysqli_error($con));
        $arrVal = array();
         
        $i=1;
         while ($rowList = mysqli_fetch_array($sqltran)) {
                                  
                        $name = array(
                                   'num' => $i,
                                   'name'=> $rowList['name'],
                                   'email_id'=> $rowList['email_id'],
								   'phone'=> $rowList['phone'],
                                   'department'=> $rowList['department'],
								   'remark'=> $rowList['remark']
                                );        
                            array_push($arrVal, $name);    
            $i++;            
         }
		 
		  echo  json_encode($arrVal);        
 
        // mysqli_close($con);

?>